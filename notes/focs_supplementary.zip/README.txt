Supplementary Material: Computational Experiments
==================================================

This archive contains 12 Python scripts that verify the key claims
in the paper "Random 3-SAT Requires Exponential-Size Extended Frege Proofs."

Requirements: Python 3.8+, NumPy, SciPy (optional for some scripts).

Each script is self-contained and prints PASS/FAIL for each test.

Files and corresponding paper claims:

  toy_353_first_moment_backbone.py
    — First moment bound: backbone = Theta(n) at alpha_c (Section 2)

  toy_298_backbone_independence.py
    — Target independence: knowing x_i doesn't help predict x_j (Section 3)

  toy_340_backbone_block_independence.py
    — Block independence: cross-block MI near zero (Section 3)

  toy_296_quiet_backbone.py
    — Computational indistinguishability: committed vs uncommitted (Section 4)

  toy_271_ac_dichotomy_verification.py
    — AC Dichotomy: I_fiat = 0 iff tractable (foundation, Section 1)

  toy_272_width_sweep_derivability.py
    — Information budget: I_derivable + I_free + I_fiat = n (Section 4)

  toy_301_expansion_silence.py
    — VIG expansion persists after backbone fixing (Section 5)

  toy_331_cheeger_expander_vig.py
    — Cheeger inequality on VIG: spectral gap implies width Omega(n) (Section 5)

  toy_303_euler_convergence.py
    — Cascade-zero: width = Omega(n) at every derivation step (Section 5)

  toy_287_overlap_gap.py
    — Overlap gap property at alpha_c: solution clusters separated (Section 2)

  toy_312_arity_tradeoff_and_band_measure.py
    — Arity-k trade-off and forbidden band measure (Section 6)

  toy_304_ac0_to_p_lift.py
    — Complete chain: backbone + topology + Cook = EF 2^{Omega(n)} (Section 7)

To run all experiments:
  for f in toy_*.py; do echo "=== $f ==="; python3 "$f"; echo; done
